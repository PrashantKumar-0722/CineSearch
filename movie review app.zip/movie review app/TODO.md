# TODO List for Fixing Movie Review App

## Tasks

- [x] Create ProtectedRoute.jsx component in src/components/ to guard authenticated routes
- [x] Update App.jsx: Import Home and ProtectedRoute; remove property-related routes (properties, property-details, add-property, cart, about-us, contact-us, bookings); add index route under /home to default to AllMovies
- [x] Update Home.jsx: Change site title link from /home/properties to /home/all-movies
- [x] Update Login.jsx: Remove the erroneous navigate("/home/properties") before checking response; change the successful login navigate to "/home"

## Followup

- [ ] Run the app and verify: Login page on start, navigate to home after login, home shows AllMovies by default, logout works, protected routes redirect to login if not authenticated
