import express from "express";
import Review from "../models/Review.js";
import { authenticateToken } from "../middleware/auth.js";

const router = express.Router();

// Get all reviews
router.get("/", async (req, res) => {
  try {
    const reviews = await Review.findAll();
    res.json(reviews);
  } catch (error) {
    console.error("Get reviews error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get my reviews (protected)
router.get("/my", authenticateToken, async (req, res) => {
  try {
    const reviews = await Review.findByUserId(req.user.id);
    res.json(reviews);
  } catch (error) {
    console.error("Get my reviews error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get review by ID
router.get("/:id", async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) {
      return res.status(404).json({ message: "Review not found" });
    }
    res.json(review);
  } catch (error) {
    console.error("Get review error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Create review (protected)
router.post("/", authenticateToken, async (req, res) => {
  try {
    const { movie_id, rating, review } = req.body;

    if (!movie_id || !rating) {
      return res
        .status(400)
        .json({ message: "Movie ID and rating are required" });
    }

    if (rating < 1 || rating > 5) {
      return res
        .status(400)
        .json({ message: "Rating must be between 1 and 5" });
    }

    const reviewId = await Review.create({
      user_id: req.user.id,
      movie_id,
      rating,
      review,
    });

    const newReview = await Review.findById(reviewId);
    res.status(201).json({
      message: "Review created successfully",
      review: newReview,
    });
  } catch (error) {
    console.error("Create review error:", error);
    if (error.message === "User has already reviewed this movie") {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: "Internal server error" });
  }
});

// Update review (protected)
router.put("/:id", authenticateToken, async (req, res) => {
  try {
    const { rating, review } = req.body;

    if (!rating) {
      return res.status(400).json({ message: "Rating is required" });
    }

    if (rating < 1 || rating > 5) {
      return res
        .status(400)
        .json({ message: "Rating must be between 1 and 5" });
    }

    // Check if review exists and belongs to user
    const existingReview = await Review.findById(req.params.id);
    if (!existingReview) {
      return res.status(404).json({ message: "Review not found" });
    }

    if (existingReview.user_id !== req.user.id) {
      return res
        .status(403)
        .json({ message: "You can only update your own reviews" });
    }

    const updatedReview = await Review.update(req.params.id, {
      rating,
      review,
    });
    res.json({
      message: "Review updated successfully",
      review: updatedReview,
    });
  } catch (error) {
    console.error("Update review error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Delete review (protected)
router.delete("/:id", authenticateToken, async (req, res) => {
  try {
    // Check if review exists and belongs to user
    const existingReview = await Review.findById(req.params.id);
    if (!existingReview) {
      return res.status(404).json({ message: "Review not found" });
    }

    if (existingReview.user_id !== req.user.id) {
      return res
        .status(403)
        .json({ message: "You can only delete your own reviews" });
    }

    await Review.delete(req.params.id);
    res.json({ message: "Review deleted successfully" });
  } catch (error) {
    console.error("Delete review error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Share review (protected)
router.post("/:id/share", authenticateToken, async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    // Check if review exists and belongs to user
    const existingReview = await Review.findById(req.params.id);
    if (!existingReview) {
      return res.status(404).json({ message: "Review not found" });
    }

    if (existingReview.user_id !== req.user.id) {
      return res
        .status(403)
        .json({ message: "You can only share your own reviews" });
    }

    await Review.share(req.params.id, req.user.id, email);
    res.json({ message: "Review shared successfully" });
  } catch (error) {
    console.error("Share review error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get shared reviews (protected)
router.get("/shared", authenticateToken, async (req, res) => {
  try {
    const sharedReviews = await Review.findSharedWithUser(req.user.email);
    res.json(sharedReviews);
  } catch (error) {
    console.error("Get shared reviews error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
