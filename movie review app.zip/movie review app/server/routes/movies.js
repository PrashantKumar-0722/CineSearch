import express from "express";
import Movie from "../models/Movie.js";

const router = express.Router();

// Get all movies
router.get("/", async (req, res) => {
  try {
    const movies = await Movie.findAll();
    res.json(movies);
  } catch (error) {
    console.error("Get movies error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get movie by ID
router.get("/:id", async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) {
      return res.status(404).json({ message: "Movie not found" });
    }
    res.json(movie);
  } catch (error) {
    console.error("Get movie error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
