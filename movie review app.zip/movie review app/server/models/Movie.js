import { query } from "../config/database.js";

class Movie {
  static async findAll() {
    const sql = "SELECT * FROM movies ORDER BY created_at DESC";
    return await query(sql);
  }

  static async findById(id) {
    const sql = "SELECT * FROM movies WHERE id = ?";
    const movies = await query(sql, [id]);
    return movies[0];
  }

  static async create(movieData) {
    const { title, year, genre, description = "", poster_url = "" } = movieData;

    const sql = `
      INSERT INTO movies (title, year, genre, description, poster_url)
      VALUES (?, ?, ?, ?, ?)
    `;

    const result = await query(sql, [
      title,
      year,
      genre,
      description,
      poster_url,
    ]);
    return result.insertId;
  }

  static async update(id, movieData) {
    const { title, year, genre, description, poster_url } = movieData;

    const sql = `
      UPDATE movies
      SET title = ?, year = ?, genre = ?, description = ?, poster_url = ?
      WHERE id = ?
    `;

    await query(sql, [title, year, genre, description, poster_url, id]);
    return this.findById(id);
  }

  static async delete(id) {
    const sql = "DELETE FROM movies WHERE id = ?";
    await query(sql, [id]);
    return true;
  }
}

export default Movie;
