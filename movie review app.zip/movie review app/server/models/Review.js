import { query } from "../config/database.js";

class Review {
  static async findAll() {
    const sql = `
      SELECT
        r.*,
        u.name as user_name,
        m.title as movie_title,
        m.year as movie_year,
        m.genre as movie_genre
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      JOIN movies m ON r.movie_id = m.id
      ORDER BY r.created_at DESC
    `;
    return await query(sql);
  }

  static async findByUserId(userId) {
    const sql = `
      SELECT
        r.*,
        m.title as movie_title,
        m.year as movie_year,
        m.genre as movie_genre
      FROM reviews r
      JOIN movies m ON r.movie_id = m.id
      WHERE r.user_id = ?
      ORDER BY r.created_at DESC
    `;
    return await query(sql, [userId]);
  }

  static async findById(id) {
    const sql = `
      SELECT
        r.*,
        u.name as user_name,
        m.title as movie_title,
        m.year as movie_year,
        m.genre as movie_genre
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      JOIN movies m ON r.movie_id = m.id
      WHERE r.id = ?
    `;
    const reviews = await query(sql, [id]);
    return reviews[0];
  }

  static async create(reviewData) {
    const { user_id, movie_id, rating, review = "" } = reviewData;

    // Check if user already reviewed this movie
    const existing = await query(
      "SELECT id FROM reviews WHERE user_id = ? AND movie_id = ?",
      [user_id, movie_id]
    );

    if (existing.length > 0) {
      throw new Error("User has already reviewed this movie");
    }

    const sql = `
      INSERT INTO reviews (user_id, movie_id, rating, review)
      VALUES (?, ?, ?, ?)
    `;

    const result = await query(sql, [user_id, movie_id, rating, review]);
    return result.insertId;
  }

  static async update(id, reviewData) {
    const { rating, review } = reviewData;

    const sql = `
      UPDATE reviews
      SET rating = ?, review = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await query(sql, [rating, review, id]);
    return this.findById(id);
  }

  static async delete(id) {
    const sql = "DELETE FROM reviews WHERE id = ?";
    await query(sql, [id]);
    return true;
  }

  static async share(reviewId, sharedByUserId, sharedWithEmail) {
    const sql = `
      INSERT INTO shares (review_id, shared_by_user_id, shared_with_email)
      VALUES (?, ?, ?)
    `;

    const result = await query(sql, [
      reviewId,
      sharedByUserId,
      sharedWithEmail,
    ]);
    return result.insertId;
  }

  static async findSharedWithUser(email) {
    const sql = `
      SELECT
        s.*,
        r.rating,
        r.review,
        r.created_at as review_created_at,
        u.name as shared_by_name,
        m.title as movie_title,
        m.year as movie_year,
        m.genre as movie_genre
      FROM shares s
      JOIN reviews r ON s.review_id = r.id
      JOIN users u ON s.shared_by_user_id = u.id
      JOIN movies m ON r.movie_id = m.id
      WHERE s.shared_with_email = ?
      ORDER BY s.shared_at DESC
    `;
    return await query(sql, [email]);
  }
}

export default Review;
