import { query } from "../config/database.js";
import { hashPassword, comparePassword } from "../utils/auth.js";

class User {
  static async create(userData) {
    const { name, email, password, bio = "" } = userData;
    const hashedPassword = await hashPassword(password);

    const sql = `
      INSERT INTO users (name, email, password, bio)
      VALUES (?, ?, ?, ?)
    `;

    const result = await query(sql, [name, email, hashedPassword, bio]);
    return result.insertId;
  }

  static async findByEmail(email) {
    const sql = "SELECT * FROM users WHERE email = ?";
    const users = await query(sql, [email]);
    return users[0];
  }

  static async findById(id) {
    const sql =
      "SELECT id, name, email, bio, created_at, updated_at FROM users WHERE id = ?";
    const users = await query(sql, [id]);
    return users[0];
  }

  static async update(id, userData) {
    const { name, email, bio } = userData;
    const sql = `
      UPDATE users
      SET name = ?, email = ?, bio = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await query(sql, [name, email, bio, id]);
    return this.findById(id);
  }

  static async verifyPassword(email, password) {
    const user = await this.findByEmail(email);
    if (!user) return null;

    const isValid = await comparePassword(password, user.password);
    if (!isValid) return null;

    // Return user without password
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }
}

export default User;
