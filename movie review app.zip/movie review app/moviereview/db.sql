-- MySQL Database Schema for Movie Review Application

-- Create database
CREATE DATABASE IF NOT EXISTS movie_review_db;
USE movie_review_db;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Movies table
CREATE TABLE movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    year INT,
    genre VARCHAR(100),
    description TEXT,
    poster_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Reviews table
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    movie_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_movie (user_id, movie_id)
);

-- Shares table (for sharing reviews with other users)
CREATE TABLE shares (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    shared_by_user_id INT NOT NULL,
    shared_with_email VARCHAR(255) NOT NULL,
    shared_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE,
    FOREIGN KEY (shared_by_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert some sample data
INSERT INTO users (name, email, password, bio) VALUES
('John Doe', 'john@example.com', '$2b$10$hashedpassword1', 'Movie enthusiast'),
('Jane Smith', 'jane@example.com', '$2b$10$hashedpassword2', 'Film critic');

INSERT INTO movies (title, year, genre, description) VALUES
('The Shawshank Redemption', 1994, 'Drama', 'Two imprisoned men bond over a number of years.'),
('The Godfather', 1972, 'Crime', 'The aging patriarch of an organized crime dynasty transfers control.'),
('The Dark Knight', 2008, 'Action', 'When the menace known as the Joker wreaks havoc.');

INSERT INTO reviews (user_id, movie_id, rating, review) VALUES
(1, 1, 5, 'An amazing movie with a powerful story.'),
(2, 2, 4, 'A classic crime drama.');
