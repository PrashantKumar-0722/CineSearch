import { ToastContainer } from "react-toastify";
import "./App.css";
import Login from "./pages/Login/Login";
import Register from "./pages/Register/Register";
import Home from "./pages/Home/Home";
import ProtectedRoute from "./components/ProtectedRoute";
import { Navigate, Route, Routes } from "react-router-dom";

import AllMovies from "./pages/AllMovies/AllMovies";
import AllReviews from "./pages/AllReviews/AllReviews";
import MyReviews from "./pages/MyReviews/MyReviews";
import ShareWithMe from "./pages/ShareWithMe/ShareWithMe";
import Profile from "./pages/Profile/Profile";

function App() {
  return (
    <div>
      <ThemeProvider>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Navigate to="/login" />} />
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />

            <Route
              path="home"
              element={
                <ProtectedRoute>
                  <Home /> {/* Home component now contains the navbar */}
                </ProtectedRoute>
              }
            >
              {/* Default route to AllMovies */}
              <Route index element={<AllMovies />} />

              {/* Movie Review related routes */}
              <Route path="all-movies" element={<AllMovies />} />
              <Route path="all-reviews" element={<AllReviews />} />
              <Route path="my-reviews" element={<MyReviews />} />
              <Route path="share-with-me" element={<ShareWithMe />} />
              <Route path="profile" element={<Profile />} />
            </Route>
          </Routes>
        </AuthProvider>
      </ThemeProvider>
      <ToastContainer />
    </div>
  );
}

export default App;
