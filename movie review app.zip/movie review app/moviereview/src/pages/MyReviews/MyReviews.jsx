import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { useAuth } from "../../contexts/AuthContext";
import "./MyReviews.css";

const MyReviews = () => {
  const [reviews, setReviews] = useState([]);
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingReview, setEditingReview] = useState(null);
  const [formData, setFormData] = useState({
    movieId: "",
    rating: 5,
    review: "",
  });
  const { user } = useAuth();

  useEffect(() => {
    fetchMovies();
    fetchMyReviews();
  }, []);

  const fetchMovies = async () => {
    try {
      // TODO: Add backend API call to fetch movies
      // const res = await axios.get(`${API_BASE_URL}/movies`);
      // setMovies(res.data);

      // Placeholder data
      setMovies([
        { id: 1, title: "The Shawshank Redemption" },
        { id: 2, title: "The Godfather" },
        { id: 3, title: "The Dark Knight" },
      ]);
    } catch (error) {
      toast.error("Failed to fetch movies");
    }
  };

  const fetchMyReviews = async () => {
    try {
      // TODO: Add backend API call to fetch user's reviews
      // const res = await axios.get(`${API_BASE_URL}/reviews/my`, {
      //   headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      // });
      // setReviews(res.data);

      // Placeholder data
      setReviews([
        {
          id: 1,
          movieId: 1,
          movieTitle: "The Shawshank Redemption",
          rating: 5,
          review: "An amazing movie with a powerful story.",
          createdAt: "2024-01-01",
        },
      ]);
    } catch (error) {
      toast.error("Failed to fetch reviews");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingReview) {
        // TODO: Add backend API call to update review
        // await axios.put(`${API_BASE_URL}/reviews/${editingReview.id}`, formData, {
        //   headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        // });
        toast.success("Review updated successfully!");
      } else {
        // TODO: Add backend API call to create review
        // await axios.post(`${API_BASE_URL}/reviews`, formData, {
        //   headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        // });
        toast.success("Review added successfully!");
      }
      setShowForm(false);
      setEditingReview(null);
      setFormData({ movieId: "", rating: 5, review: "" });
      fetchMyReviews();
    } catch (error) {
      toast.error("Failed to save review");
    }
  };

  const handleEdit = (review) => {
    setEditingReview(review);
    setFormData({
      movieId: review.movieId,
      rating: review.rating,
      review: review.review,
    });
    setShowForm(true);
  };

  const handleDelete = async (reviewId) => {
    if (window.confirm("Are you sure you want to delete this review?")) {
      try {
        // TODO: Add backend API call to delete review
        // await axios.delete(`${API_BASE_URL}/reviews/${reviewId}`, {
        //   headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        // });
        toast.success("Review deleted successfully!");
        fetchMyReviews();
      } catch (error) {
        toast.error("Failed to delete review");
      }
    }
  };

  const handleShare = async (reviewId) => {
    const email = prompt("Enter email to share with:");
    if (email) {
      try {
        // TODO: Add backend API call to share review
        // await axios.post(`${API_BASE_URL}/reviews/${reviewId}/share`, { email }, {
        //   headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        // });
        toast.success("Review shared successfully!");
      } catch (error) {
        toast.error("Failed to share review");
      }
    }
  };

  const renderStars = (rating) => {
    return "★".repeat(rating) + "☆".repeat(5 - rating);
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="d-flex justify-content-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>My Reviews</h1>
        <button
          className="btn btn-primary"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? "Cancel" : "Add Review"}
        </button>
      </div>

      {showForm && (
        <div className="card mb-4">
          <div className="card-body">
            <h5>{editingReview ? "Edit Review" : "Add New Review"}</h5>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="movieId" className="form-label">
                  Movie
                </label>
                <select
                  className="form-select"
                  id="movieId"
                  value={formData.movieId}
                  onChange={(e) =>
                    setFormData({ ...formData, movieId: e.target.value })
                  }
                  required
                >
                  <option value="">Select a movie</option>
                  {movies.map((movie) => (
                    <option key={movie.id} value={movie.id}>
                      {movie.title}
                    </option>
                  ))}
                </select>
              </div>
              <div className="mb-3">
                <label htmlFor="rating" className="form-label">
                  Rating
                </label>
                <select
                  className="form-select"
                  id="rating"
                  value={formData.rating}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      rating: parseInt(e.target.value),
                    })
                  }
                >
                  {[1, 2, 3, 4, 5].map((num) => (
                    <option key={num} value={num}>
                      {num} Star{num > 1 ? "s" : ""}
                    </option>
                  ))}
                </select>
              </div>
              <div className="mb-3">
                <label htmlFor="review" className="form-label">
                  Review
                </label>
                <textarea
                  className="form-control"
                  id="review"
                  rows="3"
                  value={formData.review}
                  onChange={(e) =>
                    setFormData({ ...formData, review: e.target.value })
                  }
                  required
                ></textarea>
              </div>
              <button type="submit" className="btn btn-success">
                {editingReview ? "Update Review" : "Add Review"}
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="row">
        {reviews.map((review) => (
          <div key={review.id} className="col-md-6 mb-4">
            <div className="card h-100">
              <div className="card-body">
                <h5 className="card-title">{review.movieTitle}</h5>
                <p className="card-text">
                  <strong>Rating:</strong>{" "}
                  <span className="text-warning">
                    {renderStars(review.rating)}
                  </span>
                  <br />
                  <strong>Review:</strong> {review.review}
                  <br />
                  <small className="text-muted">
                    Posted on: {new Date(review.createdAt).toLocaleDateString()}
                  </small>
                </p>
                <div className="d-flex gap-2">
                  <button
                    className="btn btn-sm btn-outline-primary"
                    onClick={() => handleEdit(review)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-sm btn-outline-danger"
                    onClick={() => handleDelete(review.id)}
                  >
                    Delete
                  </button>
                  <button
                    className="btn btn-sm btn-outline-info"
                    onClick={() => handleShare(review.id)}
                  >
                    Share
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyReviews;
