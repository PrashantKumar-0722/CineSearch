import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import "./ShareWithMe.css";

const ShareWithMe = () => {
  const [sharedReviews, setSharedReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSharedReviews();
  }, []);

  const fetchSharedReviews = async () => {
    try {
      // TODO: Add backend API call to fetch shared reviews
      // const res = await axios.get(`${API_BASE_URL}/reviews/shared`, {
      //   headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      // });
      // setSharedReviews(res.data);

      // Placeholder data
      setSharedReviews([
        {
          id: 1,
          movieTitle: "The Shawshank Redemption",
          sharedBy: "John Doe",
          rating: 5,
          review: "An amazing movie with a powerful story.",
          sharedAt: "2024-01-01",
        },
      ]);
    } catch (error) {
      toast.error("Failed to fetch shared reviews");
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating) => {
    return "★".repeat(rating) + "☆".repeat(5 - rating);
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="d-flex justify-content-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <h1 className="mb-4">Reviews Shared With Me</h1>
      {sharedReviews.length === 0 ? (
        <p className="text-center">No reviews have been shared with you yet.</p>
      ) : (
        <div className="row">
          {sharedReviews.map((review) => (
            <div key={review.id} className="col-md-6 mb-4">
              <div className="card h-100">
                <div className="card-body">
                  <h5 className="card-title">{review.movieTitle}</h5>
                  <p className="card-text">
                    <strong>Shared by:</strong> {review.sharedBy}
                    <br />
                    <strong>Rating:</strong>{" "}
                    <span className="text-warning">
                      {renderStars(review.rating)}
                    </span>
                    <br />
                    <strong>Review:</strong> {review.review}
                    <br />
                    <small className="text-muted">
                      Shared on:{" "}
                      {new Date(review.sharedAt).toLocaleDateString()}
                    </small>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ShareWithMe;
