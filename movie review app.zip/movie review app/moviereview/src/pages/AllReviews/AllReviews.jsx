import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import "./AllReviews.css";

const AllReviews = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      // TODO: Add backend API call to fetch all reviews
      // const res = await axios.get(`${API_BASE_URL}/reviews`);
      // setReviews(res.data);

      // Placeholder data
      setReviews([
        {
          id: 1,
          movieTitle: "The Shawshank Redemption",
          userName: "John Doe",
          rating: 5,
          review: "An amazing movie with a powerful story.",
          createdAt: "2024-01-01",
        },
        {
          id: 2,
          movieTitle: "The Godfather",
          userName: "Jane Smith",
          rating: 4,
          review: "A classic crime drama.",
          createdAt: "2024-01-02",
        },
      ]);
    } catch (error) {
      toast.error("Failed to fetch reviews");
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating) => {
    return "★".repeat(rating) + "☆".repeat(5 - rating);
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="d-flex justify-content-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <h1 className="mb-4">All Reviews</h1>
      <div className="row">
        {reviews.map((review) => (
          <div key={review.id} className="col-md-6 mb-4">
            <div className="card h-100">
              <div className="card-body">
                <h5 className="card-title">{review.movieTitle}</h5>
                <p className="card-text">
                  <strong>By:</strong> {review.userName}
                  <br />
                  <strong>Rating:</strong>{" "}
                  <span className="text-warning">
                    {renderStars(review.rating)}
                  </span>
                  <br />
                  <strong>Review:</strong> {review.review}
                  <br />
                  <small className="text-muted">
                    Posted on: {new Date(review.createdAt).toLocaleDateString()}
                  </small>
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AllReviews;
