import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import "./AllMovies.css";

const AllMovies = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMovies();
  }, []);

  const fetchMovies = async () => {
    try {
      // TODO: Add backend API call to fetch movies
      // const res = await axios.get(`${API_BASE_URL}/movies`);
      // setMovies(res.data);

      // Placeholder data
      setMovies([
        {
          id: 1,
          title: "The Shawshank Redemption",
          year: 1994,
          genre: "Drama",
        },
        { id: 2, title: "The Godfather", year: 1972, genre: "Crime" },
        { id: 3, title: "The Dark Knight", year: 2008, genre: "Action" },
      ]);
    } catch (error) {
      toast.error("Failed to fetch movies");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="d-flex justify-content-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <h1 className="mb-4">All Movies</h1>
      <div className="row">
        {movies.map((movie) => (
          <div key={movie.id} className="col-md-4 mb-4">
            <div className="card h-100">
              <div className="card-body">
                <h5 className="card-title">{movie.title}</h5>
                <p className="card-text">
                  <strong>Year:</strong> {movie.year}
                  <br />
                  <strong>Genre:</strong> {movie.genre}
                </p>
                <button className="btn btn-primary">View Reviews</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AllMovies;
