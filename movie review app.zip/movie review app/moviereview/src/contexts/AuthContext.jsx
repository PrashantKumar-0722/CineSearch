import React, { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";

const AuthContext = createContext();

export const useAuth = () => {
  return useContext(AuthContext);
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // TODO: Add backend base URL configuration here
  // const API_BASE_URL = 'http://localhost:5000/api'; // Example

  useEffect(() => {
    // Check if user is logged in on app start
    const token = localStorage.getItem("token");
    if (token) {
      // TODO: Add API call to verify token and get user data
      // Example: axios.get(`${API_BASE_URL}/auth/me`, { headers: { Authorization: `Bearer ${token}` } })
      //   .then(res => setUser(res.data))
      //   .catch(() => localStorage.removeItem('token'));
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    try {
      // TODO: Add backend login API call
      // const res = await axios.post(`${API_BASE_URL}/auth/login`, { email, password });
      // localStorage.setItem('token', res.data.token);
      // setUser(res.data.user);
      // return { success: true };

      // Placeholder for now
      console.log("Login:", email, password);
      return { success: true };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || "Login failed",
      };
    }
  };

  const register = async (name, email, password) => {
    try {
      // TODO: Add backend register API call
      // const res = await axios.post(`${API_BASE_URL}/auth/register`, { name, email, password });
      // localStorage.setItem('token', res.data.token);
      // setUser(res.data.user);
      // return { success: true };

      // Placeholder for now
      console.log("Register:", name, email, password);
      return { success: true };
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || "Registration failed",
      };
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  const value = {
    user,
    login,
    register,
    logout,
    loading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
